<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'firstName' => 'Vaibhav',
            'lastName' => 'Ojha',
            'email'    => 'vibhu@gmail.com',
            'password' => Hash::make('12345'),
            'age' => 24,
            'address' => 'Pratap Nagar, Jaipur; Malivya Nagar, Jaipur; Mansorver, Jaipur, Sanger, Jaipur',
            'remember_token' => str::random(10),
            'email_verified_at' => date("Y-m-d H:i:s", strtotime('now')),
            'created_at' => date("Y-m-d H:i:s", strtotime('now')),
            'updated_at' => date("Y-m-d H:i:s", strtotime('now'))
        ]);

        DB::table('users')->insert([
            'firstName' => 'Mritunjay',
            'lastName' => 'Kumar',
            'email'    => 'mritunjay@gmail.com',
            'password' => Hash::make('12345'),
            'age' => 25,
            'address' => 'Pratap Nagar, Jaipur; Malivya Nagar, Jaipur; Mansorver, Jaipur, Sanger, Jaipur',
            'remember_token' => str::random(10),
            'email_verified_at' => date("Y-m-d H:i:s", strtotime('now')),
            'created_at' => date("Y-m-d H:i:s", strtotime('now')),
            'updated_at' => date("Y-m-d H:i:s", strtotime('now'))
        ]);
    }
}

@extends('layouts.app')
<?php
    $userId = Auth::user()->id;

    $result = App\usersTable::where('id',$userId)->get();
    $firstName = $result[0]->firstName;
    $lastName = $result[0]->lastName;
    $age      = $result[0]->age;
    $addArr = $result[0]->address;
    $addArr = explode(";",$addArr); 
?>
@section('content')
<div class="container">
    <div class="row">
        <div class="col-lg-11 col-md-11 col-11 m-auto">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div class="table-responsive">
                        <table class="table table-borderless">
                            <tbody>
                                <tr>
                                    <th>First Name</th>
                                    <td>{{$firstName}}</td>    
                                </tr>
                                <tr>
                                    <th>Last Name </th>
                                    <td>{{$lastName}}</td>    
                                </tr>
                                <tr>
                                    <th>Age</th>   
                                    <td>{{$age}}</td> 
                                </tr>
                                <tr>
                                    <th>Address</th>  
                                    <td>
                                      <?php
                                         for($i=0;$i<sizeof($addArr);$i++)
                                         {
                                             $sno = $i+1;
                                             if(!empty($addArr[$i]))
                                             {
                                                echo "$sno. ".$addArr[$i]." <br>";
                                             }
                                         }      
                                      ?>
                                    </td>  
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card-footer">
                    <div class="form-group" style="float:left;">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#updateModal"> 
                            Edit Account</button>
                    </div>
                    <div class="form-group" style="float:right;">
                       <button class="btn btn-danger" onclick="delete1('{{$userId}}')"> Delete Account</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

<!-- The Modal Start-->
  <div class="modal fade" id="updateModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
         <form action="/user-update" method="post">
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Update</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <input type="number" name="id" value="{{$userId}}" hidden>
            @csrf
             <div class="form-group">
                <label>First Name</label>
                 <input type="text" name="firstName" class="form-control" placeholder="First Name" 
                  value="{{$firstName}}" required>
             </div>
             <div class="form-group">
                <label>Last Name</label>
                 <input type="text" name="lastName" class="form-control" placeholder="Last Name" 
                  value="{{$lastName}}" required>
             </div>
             <div class="form-group">
                <label>Age</label>
                 <input type="number" name="age" class="form-control" placeholder="Age" 
                  value="{{$age}}" required>
             </div>
             <div class="form-group" id="address">
                <label>Address</label>
                 @foreach ($addArr as $addr)
                    @if (!empty($addr))
                     <input type="text" name="addr[]" value="{{$addr}}" class="form-control">
                   @endif
                 @endforeach
             </div>
             <h4 style="float:right; cursor: pointer;" onclick="addInput()"> 
                 <i class="fa fa-plus-circle text-danger"></i> </h4>
                 <br>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
            <div>
                <button class="btn btn-primary" type="submit">Update</button>&emsp;
              <button type="button" class="btn btn-secondary" data-dismiss="modal">
              Close</button>
            </div>
            </div>
         </form>
      </div>
    </div>
  </div>
 <!-- The Modal End--> 

 <script>
     function addInput()
     {
         $("#address").append('<input type="text" name="addr[]" class="form-control" placeholder="Enter Address">')
     }
     function delete1(id)
     {
        if (confirm("Are you really want to delete") == true) 
        {
            location.href = "/user-delete/"+id;
        }
     }
 </script>
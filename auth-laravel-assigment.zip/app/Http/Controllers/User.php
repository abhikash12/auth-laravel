<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\usersTable;

class User extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    function delete($id)
    {
        $del = usersTable::find($id);
        $del->delete();
        return redirect('/home');
    }

    function update(Request $request)
    {
        $addArr = $request->addr;
        $addArr = implode(";",$addArr);

        $update = usersTable::find($request->id);
        $update->firstName = $request->firstName;
        $update->lastName = $request->lastName;
        $update->age = $request->age;
        $update->address = $addArr;
        $update->save();

        return redirect('/home')->with('status','Profile Updated');
    }
}

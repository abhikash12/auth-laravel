<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usersTable extends Model
{
    protected $primaryKey = "id";
    protected $table = "users";
    protected $fillable = ['firstName','lastName','age','address'];
}
